spb_owlim & spb_virtuoso contain select queries that test specific
aspects of the two systems. 
